import React,{Component} from 'react';
import {
  AppRegistry,
  Text,
  View,
  Button,
  SegmentedControlIOS,
  FlatList,
  StyleSheet,
} from 'react-native';
import { StackNavigator } from 'react-navigation';

import LoginScreen from './LoginScreen';

class HomeScreen extends React.Component {

  render() {
    const { navigate } = this.props.navigation;
    return (
      <View>
        <LoginSegmentedControl/>
        <LoginInputVerifyCode/>
      </View>
    );
  }
}

class LoginSegmentedControl extends Component {
  render() {
    return (
      <View>
        <View style={{marginBottom: 10}}>
          <SegmentedControlIOS
            style={{margin: 10 ,height: 35}}
            tintColor="#30cccc"
            values={['短信验证码登录', '账号登录']}
            selectedIndex={0}
          />
        </View>
      </View>
    );
  }
}

class LoginInputVerifyCode extends Component {
  render() {
    return (
      <FlatList
        data={[{key: '手机号'}, {key: '验证码'}]}
        renderItem={({item}) =>
          <View style = {styles.container}>
            <Text style = {styles.left}>{item.key}</Text>
            <Text>{item.key}</Text>
            <Text>{item.key}</Text>
            <Text>{item.key}</Text>


          </View>
          }

      />
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flexDirection:'row',
    justifyContent: 'center',
  },
  left: {
    flex:1,
    marginLeft:10,
    width:100,
    height:45,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#ff0000',
  },
  item2: {
    width: 40,
    height: 40,
    backgroundColor: '#00ff00',
  },
  item3: {
    width: 40,
    height: 40,
    backgroundColor: '#0000ff',
  },
  textContent: {
    color: '#ffffff',
    fontSize: 15,
  },
});

const RNDemos = StackNavigator({

  Home: {
    screen: HomeScreen,
    navigationOptions: {
      title: '登录111',
      titleBackgroundColor: 'red',
      headerBackgroundColor: 'red',
      headerTintColor: 'red',
      headerRight: <Button style={styles.left} title="注册" />,
    }},
});

AppRegistry.registerComponent('RNDemos', () => RNDemos);
